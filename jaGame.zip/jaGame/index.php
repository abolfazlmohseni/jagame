<!DOCTYPE html>
<html lang="fa">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>جاگیم</title>
</head>

<body>
<a href="<?php echo home_url('/login/'); ?>" class="login-button">لاگین</a>


</body>

</html>